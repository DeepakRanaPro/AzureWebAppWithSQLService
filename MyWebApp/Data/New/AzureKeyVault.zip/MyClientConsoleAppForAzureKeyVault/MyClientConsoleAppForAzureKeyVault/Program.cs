﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Azure.Security.KeyVault.Keys;
namespace key_vault_console_app
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var tenantId = "ac8e24cc-0ae2-4183-a580-3a3449361699";
            var clientId = "8956d315-4681-4cb4-bc1f-430b3e919e2e";
            var clientSecret = "6Kr8Q~PGimyaJX3DNts3RE7UttsClEizHQ7ayauN";
            var vaultUrl = "https://mywebapplicationvault.vault.azure.net/";
         
            var credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
            var client = new SecretClient(new Uri(vaultUrl), credential);

            string secretName = "MyAppConnectionString";
            KeyVaultSecret secret = await client.GetSecretAsync(secretName);
            Console.WriteLine($"Secret Value: {secret.Value}");

            // Access Key
            var keyClient = new KeyClient(new Uri(vaultUrl), credential);
            KeyVaultKey key = keyClient.GetKey("MyDemoKey1");
            Console.WriteLine($"Key Key Value: {key.Key}");
        }
    }
}