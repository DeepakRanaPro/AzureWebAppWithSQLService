﻿using CompanyWebAPIWithCosmosDB.Models;
using Microsoft.Azure.Cosmos;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;


namespace CompanyWebAPIWithCosmosDB.Services
{
    public class CosmosService : ICosmosService
    {
        private readonly Container _container;

        public CosmosService(CosmosClient client, string dbName, string containerName)
        {
            _container = client.GetContainer(dbName, containerName);
        }

        public async Task<Company> CreateAsync(Company company)
        {
            company.id ??= Guid.NewGuid().ToString();
            var response = await _container.CreateItemAsync(company, new PartitionKey(company.id));
            return response.Resource;
        }

        public async Task<Company> GetAsync(string id)
        {
            try
            {
                var response = await _container.ReadItemAsync<Company>(id, new PartitionKey(id));
                return response.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return null!;
            }
        }

        public async Task<IEnumerable<Company>> GetMultipleAsync(string queryString)
        {
            var query = _container.GetItemQueryIterator<Company>(new QueryDefinition(queryString));
            var results = new List<Company>();
            while (query.HasMoreResults)
            {
                var response = await query.ReadNextAsync();
                results.AddRange(response.Resource);
            }
            return results;
        }

        public async Task<Company> UpdateAsync(string id, Company company)
        {
            var response = await _container.UpsertItemAsync(company, new PartitionKey(id));
            return response.Resource;
        }

        public async Task DeleteAsync(string id)
        {
            await _container.DeleteItemAsync<Company>(id, new PartitionKey(id));
        }
    }

}
