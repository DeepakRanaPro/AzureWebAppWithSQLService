﻿using CompanyWebAPIWithCosmosDB.Models;

namespace CompanyWebAPIWithCosmosDB.Services
{
    public interface ICosmosService
    {
        Task<Company> CreateAsync(Company company);
        Task<Company> GetAsync(string id);
        Task<IEnumerable<Company>> GetMultipleAsync(string query);
        Task<Company> UpdateAsync(string id, Company company);
        Task DeleteAsync(string id);
    }

}
