using Microsoft.Azure.Cosmos;
 
using CompanyWebAPIWithCosmosDB.Services;

var builder = WebApplication.CreateBuilder(args);

// Bind Cosmos settings
var cosmosConfig = builder.Configuration.GetSection("CosmosDb");
string account = cosmosConfig["Account"]!;
string key = cosmosConfig["Key"]!;
string databaseName = cosmosConfig["DatabaseName"]!;
string containerName = cosmosConfig["ContainerName"]!;

// Register CosmosClient
builder.Services.AddSingleton(s => new CosmosClient(account, key));
builder.Services.AddSingleton<ICosmosService>(s =>
    new CosmosService(
        s.GetRequiredService<CosmosClient>(),
        databaseName,
        containerName));

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();