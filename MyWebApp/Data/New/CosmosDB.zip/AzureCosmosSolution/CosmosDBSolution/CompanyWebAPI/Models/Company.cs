﻿using System.Text.Json.Serialization;

namespace CompanyWebAPIWithCosmosDB.Models
{
    public class Company
    { 
        public string id { get; set; }            // Cosmos requires string id

        public string Name { get; set; }
        public List<Department>? Departments { get; set; }
    }

    public class Department
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }
        public List<Team>? Teams { get; set; }
    }

    public class Team
    {
        public int TeamId { get; set; }
        public string TeamName { get; set; }
        public List<Member>? Members { get; set; }
    }

    public class Member
    {
        public int MemberId { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; }
    }

}
