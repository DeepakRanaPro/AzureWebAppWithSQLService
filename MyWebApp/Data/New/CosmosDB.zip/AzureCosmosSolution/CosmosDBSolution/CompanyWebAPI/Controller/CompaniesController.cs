﻿using CompanyWebAPIWithCosmosDB.Models;
using CompanyWebAPIWithCosmosDB.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;



namespace CompanyWebAPIWithCosmosDB.Controller
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class CompaniesController : ControllerBase
    {
        private readonly ICosmosService _cosmosService;

        public CompaniesController(ICosmosService cosmosService)
        {
            _cosmosService = cosmosService;
        }

        [HttpGet]
        public async Task<IEnumerable<Company>> Get()
            => await _cosmosService.GetMultipleAsync("SELECT * FROM c");

        [HttpGet("{id}")]
        public async Task<ActionResult<Company>> GetById(string id)
        {
            var company = await _cosmosService.GetAsync(id);
            if (company == null) return NotFound();
            return company;
        }

        [HttpPost]
        public async Task<ActionResult<Company>> Create(Company company)
        {
            var created = await _cosmosService.CreateAsync(company);
            return CreatedAtAction(nameof(GetById), new { id = created.id }, created);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<Company>> Update(string id, Company company)
        {
            if (id != company.id) return BadRequest("ID mismatch");
            var updated = await _cosmosService.UpdateAsync(id, company);
            return Ok(updated);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await _cosmosService.DeleteAsync(id);
            return NoContent();
        }
    }

}
