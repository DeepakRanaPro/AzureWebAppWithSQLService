using Microsoft.Azure.Cosmos;
using EcommerceWebAPIWithCosmosDB.Services;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// 1. CosmosClient as Singleton
builder.Services.AddSingleton(s =>
{
    var cfg = s.GetRequiredService<IConfiguration>();
    var account = cfg["CosmosDb:Account"]!;
    var key = cfg["CosmosDb:Key"]!;
    return new CosmosClient(account, key);
});

// 2. Register CosmosDbService
builder.Services.AddSingleton<ICosmosDbService, CosmosDbService>();

// 3. Add Controllers
builder.Services.AddControllers();

// 4. Swagger/OpenAPI (optional)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// 5. Middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
 
app.UseHttpsRedirection();

app.UseRouting();
app.UseAuthorization();
app.MapControllers();  
app.Run();

internal record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
