﻿using EcommerceWebAPIWithCosmosDB.Models;

namespace EcommerceWebAPIWithCosmosDB.Services
{
    public interface ICosmosDbService
    {
        Task<IEnumerable<Product>> GetItemsAsync(string query);
        Task<Product?> GetItemAsync(string id, string partitionKey);
        Task<Product> CreateItemAsync(Product item);
        Task UpdateItemAsync(string id, string partitionKey, Product item);
        Task DeleteItemAsync(string id, string partitionKey);
    }

}
