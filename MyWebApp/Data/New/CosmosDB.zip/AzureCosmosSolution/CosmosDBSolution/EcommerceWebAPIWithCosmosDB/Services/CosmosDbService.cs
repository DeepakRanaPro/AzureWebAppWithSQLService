﻿using EcommerceWebAPIWithCosmosDB.Models;
using Microsoft.Azure.Cosmos;
 
namespace EcommerceWebAPIWithCosmosDB.Services
{
    public class CosmosDbService : ICosmosDbService
    {
        private readonly Container _container;

        public CosmosDbService(CosmosClient client, IConfiguration config)
        {
            var databaseId = config["CosmosDb:Database"]!;
            var containerId = config["CosmosDb:Container"]!;
            _container = client.GetDatabase(databaseId).GetContainer(containerId);
        }

        public async Task<Product> CreateItemAsync(Product item)
        {
            var response = await _container.CreateItemAsync(item, new PartitionKey(item.primaryCategory));
            return response.Resource;
        }

        public async Task DeleteItemAsync(string id, string partitionKey)
        {
            await _container.DeleteItemAsync<Product>(id, new PartitionKey(partitionKey));
        }

        public async Task<Product?> GetItemAsync(string id, string partitionKey)
        {
            try
            {
                var response = await _container.ReadItemAsync<Product>(id, new PartitionKey(partitionKey));
                return response.Resource;
            }
            catch (CosmosException ex) when (ex.SubStatusCode == 404)
            {
                return null;
            }
        }

        public async Task<IEnumerable<Product>> GetItemsAsync(string queryString)
        {
            var query = _container.GetItemQueryIterator<Product>(new QueryDefinition(queryString));
            var results = new List<Product>();
            while (query.HasMoreResults)
            {
                var response = await query.ReadNextAsync();
                results.AddRange(response);
            }
            return results;
        }

        public async Task UpdateItemAsync(string id, string partitionKey, Product item)
        {
            await _container.UpsertItemAsync(item, new PartitionKey(partitionKey));
        }
    }

}
