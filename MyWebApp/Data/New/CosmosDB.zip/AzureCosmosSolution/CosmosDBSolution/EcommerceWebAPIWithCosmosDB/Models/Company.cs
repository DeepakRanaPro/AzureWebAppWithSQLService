﻿using System.Text.Json.Serialization;
namespace EcommerceWebAPIWithCosmosDB.Models
{
    public class Attributes
    {
        public string color { get; set; }
        public string size { get; set; }
    }

    public class Brand
    {
        public string id { get; set; }
        public string name { get; set; }
        public string logoUrl { get; set; }
    }

    public class Discount
    {
        public string type { get; set; }
        public int value { get; set; }
        public DateTime validUntil { get; set; }
    }
     
    public class Measurements
    {
        public int chestWidthInches { get; set; }
        public int bodyLengthInches { get; set; }
    }

    public class Metadata
    {
        public DateTime createdAt { get; set; }
        public string createdBy { get; set; }
        public DateTime lastUpdatedAt { get; set; }
        public string lastUpdatedBy { get; set; }
    }

    public class Price
    {
        public string currency { get; set; }
        public double listPrice { get; set; }
        public double salePrice { get; set; }
        public Discount discount { get; set; }
    }
     
    public class Ratings
    {
        public double average { get; set; }
        public int count { get; set; }
    }

    public class Review
    {
        public string reviewId { get; set; }
        public string userId { get; set; }
        public int rating { get; set; }
        public string comment { get; set; }
        public DateTime createdAt { get; set; }
    }

    public class Product 
    {
        [JsonPropertyName("id")]
        public string id { get; set; }

        [JsonPropertyName("sku")]
        public string sku { get; set; } 

        [JsonPropertyName("name")]
        public string name { get; set; }
        [JsonPropertyName("primaryCategory")]
        public string primaryCategory { get; set; }
        public List<string> categories { get; set; }
        public Brand brand { get; set; }
        public string description { get; set; }
        public Price price { get; set; }
        public Specifications specifications { get; set; }
        public List<string> tags { get; set; }
        public Ratings ratings { get; set; }
        public List<Review> reviews { get; set; }  
        public Metadata metadata { get; set; }
    } 
    public class Specifications
    {
        public string material { get; set; }
        public List<string> careInstructions { get; set; }
        public Measurements measurements { get; set; }
    } 
}
