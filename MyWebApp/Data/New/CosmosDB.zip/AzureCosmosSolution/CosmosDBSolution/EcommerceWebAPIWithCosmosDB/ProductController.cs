﻿using EcommerceWebAPIWithCosmosDB.Models;
using EcommerceWebAPIWithCosmosDB.Services;
using Microsoft.AspNetCore.Mvc;

namespace EcommerceWebAPIWithCosmosDB
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class ProductController : ControllerBase
    {
        private readonly ICosmosDbService _cosmosService;

        public ProductController(ICosmosDbService cosmosService)
        {
            _cosmosService = cosmosService;
        }

        // GET api/product
        [HttpGet]
        public async Task<IActionResult> GetAll([FromQuery] string? category)
        {
            // simple query by category or all
            string q = category is null
                ? "SELECT * FROM c"
                : "SELECT * FROM c WHERE c.primaryCategory = @cat";
            var items = category is null
                ? await _cosmosService.GetItemsAsync(q)
                : await _cosmosService.GetItemsAsync(q).ContinueWith(t =>
                    t.Result.Where(p => p.primaryCategory == category));
            return Ok(items);
        }

        // GET api/product/{id}/{pk}
        [HttpGet("{id}/{partitionKey}")]
        public async Task<IActionResult> Get(string id, string partitionKey)
        {
            var item = await _cosmosService.GetItemAsync(id, partitionKey);
            if (item is null) return NotFound();
            return Ok(item);
        }

        // POST api/product
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Product newItem)
        {
            var created = await _cosmosService.CreateItemAsync(newItem);
            return CreatedAtAction(nameof(Get),
                new { id = created.id, partitionKey = created.primaryCategory }, created);
        }

        // PUT api/product/{id}/{pk}
        [HttpPut("{id}/{partitionKey}")]
        public async Task<IActionResult> Update(string id, string partitionKey, [FromBody] Product updateItem)
        {
            var existing = await _cosmosService.GetItemAsync(id, partitionKey);
            if (existing is null) return NotFound();

            updateItem.id = id;
            updateItem.primaryCategory = partitionKey;

            await _cosmosService.UpdateItemAsync(id, partitionKey, updateItem);
            return NoContent();
        }

        // DELETE api/product/{id}/{pk}
        [HttpDelete("{id}/{partitionKey}")]
        public async Task<IActionResult> Delete(string id, string partitionKey)
        {
            var existing = await _cosmosService.GetItemAsync(id, partitionKey);
            if (existing is null) return NotFound();

            await _cosmosService.DeleteItemAsync(id, partitionKey);
            return NoContent();
        }
    }

}
