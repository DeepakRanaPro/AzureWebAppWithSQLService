﻿using EmployeeWebAPIWithCosmosDB.Models;
using Microsoft.Azure.Cosmos;
using System.Net; 
namespace EmployeeWebAPIWithCosmosDB.Services
{
    public class CosmosService
    {
        private readonly Container _container;

        public CosmosService(IConfiguration config)
        {
            var client = new CosmosClient(
                config["Cosmos:AccountEndpoint"],
                config["Cosmos:AccountKey"]
            );

            var db = client
                .CreateDatabaseIfNotExistsAsync(config["Cosmos:DatabaseName"])
                .GetAwaiter().GetResult()
                .Database;

            var containerResponse = db
                .CreateContainerIfNotExistsAsync(
                    id: config["Cosmos:ContainerName"],
                    partitionKeyPath: "/id"
                )
                .GetAwaiter().GetResult();

            _container = containerResponse.Container;
        }


        public async Task<Employee> AddEmployeeAsync(Employee emp)
        {
            emp.id = Guid.NewGuid().ToString();
            var response = await _container.CreateItemAsync(emp, new PartitionKey(emp.id));
            return response.Resource;
        }

        public async Task<List<Employee>> GetEmployeesAsync()
        {
            var query = _container.GetItemQueryIterator<Employee>("SELECT * FROM c");
            var results = new List<Employee>();
            while (query.HasMoreResults)
            {
                var page = await query.ReadNextAsync();
                results.AddRange(page);
            }
            return results;
        }

        public async Task<Employee?> GetEmployeeAsync(string id)
        {
            try
            {
                var response = await _container.ReadItemAsync<Employee>(id, new PartitionKey(id));
                return response.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }
        }

        public async Task<Employee?> UpdateEmployeeAsync(string id, Employee emp)
        {
            emp.id = id;
            var response = await _container.UpsertItemAsync(emp, new PartitionKey(id));
            return response.Resource;
        }

        public async Task<bool> DeleteEmployeeAsync(string id)
        {
            try
            {
                await _container.DeleteItemAsync<Employee>(id, new PartitionKey(id));
                return true;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return false;
            }
        }
    }

}
