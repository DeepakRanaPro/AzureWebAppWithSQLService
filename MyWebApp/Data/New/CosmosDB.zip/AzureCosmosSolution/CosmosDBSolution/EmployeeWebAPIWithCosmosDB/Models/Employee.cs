﻿namespace EmployeeWebAPIWithCosmosDB.Models
{
    public class Employee
    {
        public string id { get; set; } // required by Cosmos
        public string name { get; set; }
        public string department { get; set; }
        public bool isPermanent { get; set; }
    }

}
