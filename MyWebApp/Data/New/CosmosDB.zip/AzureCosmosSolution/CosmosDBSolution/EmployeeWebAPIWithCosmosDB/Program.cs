using EmployeeWebAPIWithCosmosDB.Services;

var builder = WebApplication.CreateBuilder(args);

// Register CosmosService as singleton
builder.Services.AddSingleton<CosmosService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


// Add services to the container.

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();

// Configure the HTTP request pipeline.

app.UseHttpsRedirection();
// THIS wires up [ApiController] routes
app.MapControllers();

app.Run();
 
