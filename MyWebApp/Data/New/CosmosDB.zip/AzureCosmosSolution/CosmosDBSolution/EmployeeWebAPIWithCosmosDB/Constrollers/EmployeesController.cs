﻿using EmployeeWebAPIWithCosmosDB.Models;
using EmployeeWebAPIWithCosmosDB.Services;
using Microsoft.AspNetCore.Mvc;
namespace EmployeeWebAPIWithCosmosDB.Constrollers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class EmployeesController : ControllerBase
    {
        private readonly CosmosService _cosmos;

        public EmployeesController(CosmosService cosmos)
        {
            _cosmos = cosmos;
        }

        // POST api/employees
        [HttpPost]
        public async Task<ActionResult<Employee>> Create(Employee emp)
        {
            var created = await _cosmos.AddEmployeeAsync(emp);
            return CreatedAtAction(nameof(GetById), new { id = created.id }, created);
        }

        // GET api/employees
        [HttpGet]
        public async Task<ActionResult<List<Employee>>> GetAll()
        {
            var list = await _cosmos.GetEmployeesAsync();
            return Ok(list);
        }

        // GET api/employees/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Employee>> GetById(string id)
        {
            var emp = await _cosmos.GetEmployeeAsync(id);
            if (emp is null) return NotFound();
            return Ok(emp);
        }

        // PUT api/employees/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, Employee emp)
        {
            var updated = await _cosmos.UpdateEmployeeAsync(id, emp);
            if (updated is null) return NotFound();
            return Ok(updated);
        }

        // DELETE api/employees/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var deleted = await _cosmos.DeleteEmployeeAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }

}
