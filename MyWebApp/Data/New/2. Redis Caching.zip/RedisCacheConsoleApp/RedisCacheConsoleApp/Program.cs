﻿using StackExchange.Redis;

class Program
{
    static async Task Main(string[] args)
    { 
        string connectionString = "OptumRedisCache.redis.cache.windows.net:6380,password=SAJ5tjA8AOtKaZtfo43rLb9FCNrmKV0t3AzCaC17q9E=,ssl=True,abortConnect=False";

        Console.WriteLine("Connecting to Azure Redis Cache...");
        var redis = await ConnectionMultiplexer.ConnectAsync(connectionString);
        IDatabase db = redis.GetDatabase();

        // Set a key
        await db.StringSetAsync("MyDemoDataKey", "This is Test Data");

        // Get the key
        string value = await db.StringGetAsync("MyDemoDataKey");
        Console.WriteLine($"Retrieved from Redis: {value}");

        // Optional: Close connection
        redis.Close();
    }
}
