﻿using Azure.Messaging.ServiceBus;

namespace AzureServiceBus.Queue.ReceiverConsoleApp
{
    class Program
    {
        // Replace with your Service Bus connection string and queue name
        private const string connectionString = "Endpoint=sb://optumservicebus.servicebus.windows.net/;SharedAccessKeyName=AdminAccess;SharedAccessKey=WdtaejJvr/4RueJgg+jBZoHN68i9pdomc+ASbMaNogE=;EntityPath=optumdataqueue1";
        private const string queueName = "optumdataqueue1";
        static ServiceBusClient client;
        static ServiceBusProcessor processor;
        static async Task Main(string[] args)
        {
            client = new ServiceBusClient(connectionString);
            processor = client.CreateProcessor(queueName, new ServiceBusProcessorOptions() { ReceiveMode = ServiceBusReceiveMode.PeekLock, AutoCompleteMessages = false });
            processor.ProcessMessageAsync += MessageHandler;
            processor.ProcessErrorAsync += ErrorHandler;
            await processor.StartProcessingAsync();
            Console.WriteLine("Wait for a minute and then press any key to end the processing");
            Console.ReadKey();

            // stop processing
            Console.WriteLine("\nStopping the receiver...");
            await processor.StopProcessingAsync();
            Console.WriteLine("Stopped receiving messages");
            await processor.DisposeAsync();
            await client.DisposeAsync();

            //await ReceiveMessageAsync();
        }

        static async Task MessageHandler(ProcessMessageEventArgs args)
        {
            string body = args.Message.Body.ToString();
            Console.WriteLine($"Received: {body}, Count: {args.Message.DeliveryCount}");
            await args.CompleteMessageAsync(args.Message);
        }
        static Task ErrorHandler(ProcessErrorEventArgs args)
        {
            Console.WriteLine(args.Exception.ToString());
            return Task.CompletedTask;
        }
        static async Task ReceiveMessage2Async()
        {

        }

            static async Task ReceiveMessageAsync()
        {
            Console.WriteLine("Starting receiver...");

            await using var client = new ServiceBusClient(connectionString);
            ServiceBusReceiver receiver = client.CreateReceiver(queueName);

            while (true)
            {
                ServiceBusReceivedMessage message = await receiver.ReceiveMessageAsync(TimeSpan.FromSeconds(5));

                if (message == null)
                {
                    Console.WriteLine("No more messages in the queue.");
                    break;
                }

                string body = message.Body.ToString();
                Console.WriteLine($"Received: {body}");

                await receiver.CompleteMessageAsync(message);
            }

            Console.WriteLine("Receiver finished.");
        }
    }

}
