﻿using Azure.Messaging.ServiceBus;
namespace AzureServiceBus.Queue.SenderConsoleApp
{
    class Program
    {
        // Replace with your Service Bus connection string and queue name
        private const string connectionString = "Endpoint=sb://optumservicebus.servicebus.windows.net/;SharedAccessKeyName=AdminAccess;SharedAccessKey=WdtaejJvr/4RueJgg+jBZoHN68i9pdomc+ASbMaNogE=;EntityPath=optumdataqueue1";
        private const string queueName = "optumdataqueue1";
        static async Task Main(string[] args)
        {
            Console.WriteLine("Enter messages to send to the queue. Type 'exit' to quit.");

            await using var client = new ServiceBusClient(connectionString);
            ServiceBusSender sender = client.CreateSender(queueName);
             
            await SendMessageWithDefaultPropertyAsync(sender);
            Console.WriteLine("All messages sent. Exiting.");
        }

        static async Task SendMessageWithDefaultPropertyAsync(ServiceBusSender sender)
        {
            using ServiceBusMessageBatch messageBatch = await sender.CreateMessageBatchAsync();
            while (true)
            {
                Console.WriteLine("Enter Message (exit to terminate): ");
                string m = Console.ReadLine();
                if (m == "exit")
                    break;
                var msg = new ServiceBusMessage(m);
                msg.ApplicationProperties.Add("Author", "Deepak");
                msg.ApplicationProperties.Add("CreatedAt", DateTime.Now);
                msg.ApplicationProperties.Add("Source", "DemoApp");
                msg.TimeToLive = new TimeSpan(0, 0, 5);
                msg.MessageId = msg.GetHashCode().ToString();
                await sender.SendMessageAsync(msg);
                Console.WriteLine("Sent...");
            }
            await sender.DisposeAsync();
        } 
        static async Task SendMessageAsync(ServiceBusSender sender)
        {
            string messageBody = string.Empty;
            while (true)
            {
                Console.Write("Message: ");
                string input = Console.ReadLine();

                if (string.Equals(input, "exit", StringComparison.OrdinalIgnoreCase))
                    break;

                if (!string.IsNullOrWhiteSpace(input))
                {
                    ServiceBusMessage message = new ServiceBusMessage(input);
                    await sender.SendMessageAsync(message);
                    Console.WriteLine($"Sent: {input}");
                }

            }
        }
    } 
}
