﻿using Azure.Messaging.ServiceBus;

namespace AzureServiceBusTopic.ReceiverTransaction_ConsoleApp 
{
    class ReceiverApp
    {
        private const string connectionString = "<your-service-bus-connection-string>";
        private const string queueName = "<your-queue-name>";

        static async Task Main()
        {
            await using var client = new ServiceBusClient(connectionString);
            ServiceBusReceiver receiver = client.CreateReceiver(queueName);

            // Receive a batch of messages
            IReadOnlyList<ServiceBusReceivedMessage> receivedMessages = await receiver.ReceiveMessagesAsync(maxMessages: 3);

            if (receivedMessages.Count > 0)
            {
                using var transaction = await client.CreateTransactionAsync();

                foreach (var message in receivedMessages)
                {
                    Console.WriteLine($"📨 Received: {message.Body}");

                    // Complete each message within the transaction
                    await receiver.CompleteMessageAsync(message, transaction);
                }

                await transaction.CommitAsync();
                Console.WriteLine("✅ All messages processed and transaction committed.");
            }
            else
            {
                Console.WriteLine("⚠️ No messages received.");
            }
        }
    }
}