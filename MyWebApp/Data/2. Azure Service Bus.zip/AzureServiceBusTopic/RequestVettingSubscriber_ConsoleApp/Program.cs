﻿using Azure.Messaging.ServiceBus;


namespace AzureServiceBusTopic.RequestVettingSubscriber_ConsoleApp
{
    class TopicReceiver
    {
        private const string connectionString = "Endpoint=sb://optumservicebus.servicebus.windows.net/;SharedAccessKeyName=Admin;SharedAccessKey=lDDMNMpRe7IsS39yga+PpW86aV8ypDNuM+ASbNbvOts=;EntityPath=ftpsvettingengine";
        private const string topicName = "ftpsvettingengine";
        private const string subscriptionName = "VettingRequest";
 
    static async Task Main(string[] args)
        {
            await using var client = new ServiceBusClient(connectionString);
            ServiceBusReceiver receiver = client.CreateReceiver(topicName, subscriptionName);

            Console.WriteLine("Receiver (RequestVetting Subscriber) started. Type 'exit' to stop.");

            var cancellationSource = new CancellationTokenSource();

            // Start a background task to listen for exit command
            Task.Run(() =>
            {
                while (true)
                {
                    string input = Console.ReadLine();
                    if (input?.ToLower() == "exit")
                    {
                        cancellationSource.Cancel();
                        break;
                    }
                }
            });

            try
            {
                while (!cancellationSource.Token.IsCancellationRequested)
                {
                    ServiceBusReceivedMessage message = await receiver.ReceiveMessageAsync(TimeSpan.FromSeconds(2), cancellationSource.Token);

                    if (message != null)
                    {
                        string body = message.Body.ToString();
                        Console.WriteLine($"📨 Received: {body}");

                        await receiver.CompleteMessageAsync(message);
                    }
                }
            }
            catch (TaskCanceledException)
            {
                Console.WriteLine("Receiver stopped by user.");
            }

            Console.WriteLine("Exiting receiver.");

        }
    }
    }
