﻿using Azure.Messaging.ServiceBus; 
 

namespace AzureServiceBusTopic.SenderTransaction_ConsoleApp
{

    class SenderApp
    {
        private const string connectionString = "<your-service-bus-connection-string>";
        private const string queueName = "<your-queue-name>";

        static async Task Main()
        {
            await using var client = new ServiceBusClient(connectionString);
            ServiceBusSender sender = client.CreateSender(queueName);

            using var transaction = await client.CreateTransactionAsync();
   
            // Create a batch of messages
            var messages = new List<ServiceBusMessage>
        {
            new ServiceBusMessage("Message 1"),
            new ServiceBusMessage("Message 2"),
            new ServiceBusMessage("Message 3")
        };

            // Send each message in the transaction
            foreach (var msg in messages)
            {
                await sender.SendMessageAsync(msg, transaction);
            }

            await transaction.CommitAsync();
            Console.WriteLine("✅ All messages sent in a single transaction.");
        }
    }
}