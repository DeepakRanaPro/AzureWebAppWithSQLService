﻿using Azure.Messaging.ServiceBus;

class SessionReceiver
{
    private const string connectionString = "Endpoint=sb://optumservicebus.servicebus.windows.net/;SharedAccessKeyName=Admin;SharedAccessKey=lDDMNMpRe7IsS39yga+PpW86aV8ypDNuM+ASbNbvOts=;EntityPath=ftpsvettingengine";
    private const string topicName = "ftpsvettingengine";
    private const string subscriptionName = "SessionRequest";

    static async Task Main(string[] args)
    {
        await using var client = new ServiceBusClient(connectionString);

        Console.WriteLine("Session receiver started. Type 'exit' to stop.");

        var cancellationSource = new CancellationTokenSource();

        // Background task to listen for 'exit'
        Task task = Task.Run(() =>
        {
            while (true)
            {
                string input = Console.ReadLine();
                if (input?.ToLower() == "exit")
                {
                    cancellationSource.Cancel();
                    break;
                }
            }
        });

        try
        {
            while (!cancellationSource.Token.IsCancellationRequested)
            {
                var options = new ServiceBusSessionReceiverOptions
                {
                    ReceiveMode = ServiceBusReceiveMode.PeekLock
                };
                // Accept the next available session
                ServiceBusSessionReceiver sessionReceiver = await client.AcceptNextSessionAsync(topicName, subscriptionName, options, cancellationSource.Token);

                Console.WriteLine($"🔗 Accepted session: {sessionReceiver.SessionId}");

                while (!cancellationSource.Token.IsCancellationRequested)
                {
                    ServiceBusReceivedMessage message = await sessionReceiver.ReceiveMessageAsync(TimeSpan.FromSeconds(2), cancellationSource.Token);

                    if (message != null)
                    {
                        Console.WriteLine($"📨 Received from session {sessionReceiver.SessionId}: {message.Body}");

                        await sessionReceiver.CompleteMessageAsync(message);
                    }
                    else
                    {
                        break; // No more messages in this session
                    }
                }

                await sessionReceiver.CloseAsync();
            }
        }
        catch (TaskCanceledException)
        {
            Console.WriteLine("Receiver stopped by user.");
        }

        Console.WriteLine("Exiting session receiver.");
    }
}
