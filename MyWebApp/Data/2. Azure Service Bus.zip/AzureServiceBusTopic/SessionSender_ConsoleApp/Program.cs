﻿using Azure.Messaging.ServiceBus;

namespace AzureServiceBusTopic.SessionConsoleApp 
{
    class TopicSender
    {
        private const string connectionString = "Endpoint=sb://optumservicebus.servicebus.windows.net/;SharedAccessKeyName=Admin;SharedAccessKey=lDDMNMpRe7IsS39yga+PpW86aV8ypDNuM+ASbNbvOts=;EntityPath=ftpsvettingengine";
        private const string topicName = "ftpsvettingengine";

        static async Task Main(string[] args)
        {
            await using var client = new ServiceBusClient(connectionString);
            ServiceBusSender sender = client.CreateSender(topicName);

            Console.WriteLine("Enter messages to publish to the topic. Type 'exit' to quit.");

            while (true)
            {
                Console.Write("Message: ");
                string input = Console.ReadLine();

                if (input?.ToLower() == "exit") break;

                if (!string.IsNullOrWhiteSpace(input))
                {
                    ServiceBusMessage message = new ServiceBusMessage(input)
                    {
                        SessionId = "my-session-id" // Required for session-enabled subscriptions
                    };

                    await sender.SendMessageAsync(message);
                    Console.WriteLine($"✅ Published: {input}");
                }
            }
        }
    }
}