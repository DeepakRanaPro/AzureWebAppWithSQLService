using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace MyFirstCliFunApp
{
    public class QueueDemo
    {
        [FunctionName("QueueDemo")]
        public void Run([QueueTrigger("mytest1", Connection = "")]string myQueueItem, ILogger log)
        {
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");
        }
    }
}
